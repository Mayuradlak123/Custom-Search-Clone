export const key = "AIzaSyBe0fV9Iv597I4YwC5aZkyG6LNqol4RGQc";
export const cx = "81bad5e1fdcdb8dd1";
//AIzaSyBe0fV9Iv597I4YwC5aZkyG6LNqol4RGQc
//
// https://cse.google.com/cse?cx=81bad5e1fdcdb8dd1